// Archivo: my_ls.c

#include <stdio.h>
#include <sys/types.h>	// Para stat
#include <sys/stat.h>	// Para stat
#include <unistd.h>	// Para stat y getopt
#include <dirent.h>	// Para opendir, readdir, closedir
#include <stdlib.h>	// Para exit,
#include <string.h>	// Para strcpy

#define TRUE 1
#define FALSE 0
#define BUFSIZE 1024

/* Definicion de sinonimos */
typedef struct dirent * pdirent;
//typedef struct stat * pstat;
typedef struct inode * pinode;

/* VARIABLES GLOBALES */
char * prog_name;
DIR * directory;
pdirent pointerDirent;
pinode pointerInode;
struct stat Buf;	// donde stat deja la informacion
int retStat;		// lo que retorna stat
char namebuf[BUFSIZE];  // arreglo de caracteres: almacena nombres de archivos
int name_len;		// almacena tama�o de cada nombre de archivo

/*-----------------------------------------------------
 * 	argv[0] <==> "my_ls\0"
 * 	argv[1] <==> <opcion>
 * 	argv[2] <==> <directorio>
 *-----------------------------------------------------*/

/* FUNCIONES */
void message(FILE * stream, int exit_code)
{
   fprintf( stream ,"\nUso: %s <opcion> <directorio> \n", prog_name );
   fprintf( stream ,
           "\nPRIMER ARGUMENTO INDICA LAS OPCIONES DE LISTADO: \n"
           "PUEDEN SER UNA DE ENTRE LAS SIGUIENTES OPCIONES:\n"
           "    -e      LISTA TODOS LOS ARCHIVOS CONTENIDOS EN <directorio>\n"
           "    -d      LISTA SOLO LOS DIRECTORIOS CONTENIDOS EN <directorio>\n"
           "    -i      LISTA EL NUMERO DE I-NODO Y EL NOMBRE DE LOS ARCHIVOS CONTENIDOS EN <directorio>\n"
           );
   exit(exit_code);
}

void print_all_archives( char ** argv )
{
	if( (directory = opendir(argv[2])) == NULL )
	{
		fprintf( stderr , "\nERROR AL HACER opendir SOBRE LA RUTA!\n");
		exit(EXIT_FAILURE);
	}
	pointerDirent = readdir(directory);
	while(pointerDirent)
	{
		printf("%s \n" , pointerDirent->d_name );
		pointerDirent = readdir(directory);
	}
	closedir(directory); /* cierra el flujo de directorio */
}

void print_all_directories( char ** argv )
{
	if( strcpy(namebuf, argv[2]) == NULL )
	{
		fprintf( stderr , "\nERROR AL HACER strcpy SOBRE LA RUTA!\n");
		exit(EXIT_FAILURE);
	}
	name_len = strlen( namebuf );
	
	if( (directory = opendir(namebuf)) == NULL )
	{
		fprintf( stderr , "\nERROR AL HACER opendir SOBRE LA RUTA!\n");
		exit(EXIT_FAILURE);
	}		
	//pointerDirent = readdir(directory);
	while( (pointerDirent = readdir(directory)) )
	{
		namebuf[name_len] = '\0'; //pone marca de fin de cadena de caracteres
		strcat(namebuf, "/");	// concatena a�ade en namebuf "/"
		strcat(namebuf, pointerDirent->d_name);	
		// a�ade en namebuf el nombre de archivo correspondiente a esa entrada
		// de directorio actual
		
		if( (retStat = stat(namebuf, &Buf))== -1)
		{
			fprintf( stderr , "\nERROR AL HACER stat SOBRE LA RUTA!\n");
			exit(EXIT_FAILURE);
		}
		if( S_ISDIR(Buf.st_mode) ) // ver man 2 stat
		{
			printf("%s \n" , namebuf );
			/* s�lo imprime directorios */
		}
		//pointerDirent = readdir(directory);
	}
	closedir(directory); /* cierra el flujo de directorio */
}

void print_all_inodes_and_names( char ** argv )
{
	if( (directory = opendir(argv[2])) == NULL )
	{
		fprintf( stderr , "\nERROR AL HACER opendir SOBRE LA RUTA!\n");
		exit(EXIT_FAILURE);
	}
	pointerDirent = readdir(directory);
	while(pointerDirent)
	{
		printf("%d\t%s \n", pointerDirent->d_ino, pointerDirent->d_name );
		pointerDirent = readdir(directory);
	}
	closedir(directory); /* cierra el flujo de directorio */
}

int main (int argc, char ** argv) 
{
   int nextOpt;

   /* Opciones cortas */
   char * shortsOptions = "e:d:i:"; // ":" indica que la opcion recibe un argumento 

   prog_name = argv[0];

   if (argc < 3 || argc > 3)
      message(stderr, 1);

   do{
	nextOpt = getopt(argc, argv, shortsOptions);
	if( nextOpt == -1 ) /* Fin de lista de argumentos */
		break;
	switch( nextOpt )
	{
		case 'e':
			print_all_archives( argv );
			break;			
		case 'd': 
			print_all_directories( argv );
			break;

		case 'i': 
			print_all_inodes_and_names( argv );
			break;

		case '?':
			fprintf(stderr, "\nUNKNOWN ARGUMENT!!!\n");
			break;

		default:
			break;
	}
   }
   while( nextOpt != -1 );

   return 0; /* informa al entorno salida exitosa */
}
// Fin del Archivo: my_ls.c
