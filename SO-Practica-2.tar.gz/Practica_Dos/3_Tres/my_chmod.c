// Archivo: my_chmod.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

/* DEFINICIONES */
#define TRUE 1
#define FALSE 0

//struct de datos para <quien>
struct who {
	int u;
	int g;
	int o;
};

typedef struct who * pwho;

// struct de datos para  <+|-> 
struct action {
	int mas;
	int menos;
};

typedef struct action * paction;

// struct de datos para <modo> 
struct mode {
	int r;
	int w;
	int x;
};

typedef struct mode * pmode;

/* VARIABLES GLOBALES */
char * prog_name;
char * arg1, arg2, arg3;

/*** FUNCIONES ***/
/**
 * FUNCI�N: 	message
 * PROTOTIPO:	void message( FILE * , int )
 * FINALIDAD: 	IMPRIME MENSAJE DE ERROR.
 * */
void message(FILE * stream, int exit_code)
{
	fprintf(stream,"Uso: %s <quien> <+|-> <modo> <path> \n\n", prog_name );
	fprintf(stream,
		"PRIMER ARGUMENTO: <quien> INDICA A QUIEN SE APLICA LOS PERMISOS. \n"
		"\tPUEDE SER CUALQUIER COMBINACI�N SIN REPETICI�N DE:\n"
		"\tu		INDICA QUE LOS PERMISOS SE APLICAN AL USUARIO DUE�O.\n"
		"\tg		INDICA QUE LOS PERMISOS SE APLICAN AL GRUPO.\n"
		"\to		INDICA QUE LOS PERMISOS SE APLICAN AL RESTO.\n"
		"\tO DE OTRA MANERA PUEDE INDICAR QUE LOS PERMISOS SE APLICAN A TODOS LOS USUARIOS\n"
		"\tMEDIANTE EL ARGUMENTO:\n"
		"\ta\n"
		"SEGUNDO ARGUMENTO: <+|-> INDICA COMO SE REALIZA LA APLICACION DE LOS PERMISOS: \n"
		"\t+		INDICA OTORGAMIENTO DE PERMISOS.\n"
		"\t-		INDICA DENEGACI�N DE PERMISOS.\n"
		"TERCER ARGUMENTO INDICA EL MODO EN QUE SE APLICAN LOS PERMISOS: \n"
		"PUEDE SER CUALQUIER COMBINACI�N SIN REPETICI�N DE LAS LETRAS:\n"
		"\tr		INDICA PERMISO PARA LECTURA-LISTADO.\n"
		"\tw		INDICA PERMISO PARA ESCRITURA-MODIFICACION.\n"
		"\tx		INDICA PERMISO PARA EJECUCION-ACCESO.\n"
		"CUARTO ARGUMENTO INDICA EL PATH DEL ARCHIVO O DIRECTORIO.\n"
		);
	exit(exit_code);
}

/**
 * FUNCI�N: 	scan
 * PROTOTIPO: 	void scan( char **, pwho, paction, pmode )
 * FINALIDAD: 	ANALIZA LOS ARGUMENTOS DEL PROGRAMA.
 * 		SETEA LAS ESTRUCTURAS DE DATOS PARA DECIDIR QUE HACER.
 * */
void scan( char ** argv, pwho pquien, paction paccion, pmode pmodo  )
{
	if( argv != NULL )
	{
		if( argv[1] != NULL )
		{
			if( 
			    (strcmp(argv[1], " ") == 0) || 
			    (strcmp(argv[1], "a") == 0) ||
			    (strcmp(argv[1], "ugo") == 0) ||
			    (strcmp(argv[1], "uog") == 0) ||
			    (strcmp(argv[1], "oug") == 0) ||
			    (strcmp(argv[1], "ogu") == 0) ||
			    (strcmp(argv[1], "guo") == 0) ||
			    (strcmp(argv[1], "gou") == 0)
			  )
			{
				pquien->u = TRUE;
				pquien->g = TRUE;
				pquien->o = TRUE;
			}
			else if( strcmp(argv[1], "u") == 0)
			{
				pquien->u = TRUE;
			}
			else if( strcmp(argv[1], "g") == 0)
			{
				pquien->g = TRUE;
			}
			if( strcmp(argv[1], "o") == 0)
			{
				pquien->o = TRUE;
			}
			else if( (strcmp( argv[1], "ug" ) == 0) ||
				 (strcmp( argv[1], "gu" ) == 0)
			       )
			{
				pquien->u = TRUE;
				pquien->g = TRUE;
			}
			else if( (strcmp( argv[1], "uo") == 0) ||
				 (strcmp( argv[1], "ou") == 0)
			       )
			{
				pquien->u = TRUE;
				pquien->o = TRUE;
			}
			else if( (strcmp( argv[1], "og") == 0) ||
				 (strcmp( argv[1], "go") == 0)
			       )
			{
				pquien->o = TRUE;
				pquien->g = TRUE;
			}
		}
		else
		{
			message(stderr, EXIT_FAILURE);
		}
		
		if( argv[2] != NULL )
		{
			if( strcmp(argv[2], "+") == 0 )
			{
				paccion->mas = TRUE;
			}
			else if( strcmp(argv[2], "-") == 0 )
			{
				paccion->menos = TRUE;
			}
			else
			{
				paccion->mas = FALSE;
				paccion->menos = FALSE;
				message(stderr, EXIT_FAILURE);
			}
		}
		else
		{
			message(stderr, EXIT_FAILURE);
		}
		
		if( argv[3] != NULL )
		{
			if( (strcmp( argv[3], "rwx") == 0) ||
			    (strcmp( argv[3], "rxw") == 0) ||
			    (strcmp( argv[3], "wrx") == 0) ||
			    (strcmp( argv[3], "wxr") == 0) ||
			    (strcmp( argv[3], "xrw") == 0) ||
			    (strcmp( argv[3], "xwr") == 0)
			  )
			{
				pmodo->r = TRUE;
				pmodo->w = TRUE;
				pmodo->x = TRUE;
			}
			else if( (strcmp( argv[3], "rw") == 0) ||
				 (strcmp( argv[3], "wr") == 0)
			       )
			{
				pmodo->r = TRUE;
				pmodo->w = TRUE;
			}
			else if( (strcmp( argv[3], "rx") == 0) || 
				 (strcmp( argv[3], "xr") == 0)
			       )
			{
				pmodo->r = TRUE;
				pmodo->x = TRUE;
			}
			else if( (strcmp( argv[3], "wx") == 0) ||
				 (strcmp( argv[3], "xw") == 0)
			       )
			{
				pmodo->w = TRUE;
				pmodo->x = TRUE;
			}
			else if( strcmp( argv[3], "r") == 0 )
			{
				pmodo->r = TRUE;
			}
			else if( strcmp( argv[3], "w") == 0 )
			{
				pmodo->w = TRUE;
			}
			else if( strcmp( argv[3], "x") == 0 )
			{
				pmodo->x = TRUE;
			}
			else
			{
				pmodo->r = FALSE;
				pmodo->w = FALSE;
				pmodo->x = FALSE;
				message(stderr, EXIT_FAILURE);
			}
		}
		else
		{
			message(stderr, EXIT_FAILURE);
		}
		
		if( argv[4] == NULL )
		{
			message(stderr, EXIT_FAILURE);
		}
	}
}

/**
 * FUNCI�N: 	choose
 * PROTOTIPO: 	void choose( char **, pwho, paction, pmode )
 * FINALIDAD:	ANALIZA LAS ESTRUCTURAS DE DATOS SETEADAS
 * 		DECIDE LA MANERA EN QUE APLICA "chmod"
 * */
void choose( char ** argv, pwho pquien, paction paccion, pmode pmodo )
{
	if( paccion->mas == TRUE )							// SE OTROGA PERMISO
	{
		if( (pquien->u == FALSE && pquien->g == FALSE && pquien->o == FALSE) ||	//COMPORTAMIENTO chmod
		    (pquien->u == TRUE  && pquien->g == TRUE  && pquien->o == TRUE) )	// A TODOS
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], S_IRUSR|S_IRGRP|S_IROTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], S_IWUSR|S_IWGRP|S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], S_IXUSR|S_IXGRP|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], S_IRUSR|S_IRGRP|S_IROTH|
						    S_IWUSR|S_IWGRP|S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRUSR|S_IRGRP|S_IROTH|
						    S_IXUSR|S_IXGRP|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IWUSR|S_IWGRP|S_IWOTH|
						    S_IXUSR|S_IXGRP|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRUSR|S_IRGRP|S_IROTH|
						    S_IWUSR|S_IWGRP|S_IWOTH|
						    S_IXUSR|S_IXGRP|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == TRUE && pquien->g == FALSE && pquien->o == FALSE )	//AL USUARIO
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], S_IRUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], S_IWUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], S_IXUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], S_IRUSR|S_IWUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRUSR|S_IXUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IWUSR|S_IXUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRUSR|S_IWUSR|S_IXUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == FALSE && pquien->g == TRUE && pquien->o == FALSE ) //AL GRUPO
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], S_IRGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], S_IWGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], S_IRGRP|S_IWGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRGRP|S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IWGRP|S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRGRP|S_IWGRP|S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == FALSE && pquien->g == FALSE && pquien->o == TRUE ) //A LOS OTROS
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], S_IROTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], S_IROTH|S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IROTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IWOTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IROTH|S_IWOTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == TRUE && pquien->g == TRUE && pquien->o == FALSE) // AL USUARIO
										       // AL GRUPO
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], S_IRUSR|S_IRGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], S_IWUSR|S_IWGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], S_IXUSR|S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], S_IRUSR|S_IRGRP|S_IWUSR|S_IWGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRUSR|S_IRGRP|S_IXUSR|S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IWUSR|S_IWGRP|S_IXUSR|S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRUSR|S_IWUSR|S_IXUSR|
						    S_IRGRP|S_IWGRP|S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == TRUE && pquien->g == FALSE && pquien->o == TRUE ) //AL USUARIO
											//A LOS OTROS
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], S_IRUSR|S_IROTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], S_IWUSR|S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], S_IXUSR|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], S_IRUSR|S_IWUSR|S_IROTH|S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRUSR|S_IXUSR|S_IROTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IWUSR|S_IXUSR|S_IWOTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRUSR|S_IWUSR|S_IXUSR|
						    S_IROTH|S_IWOTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == FALSE && pquien->g == TRUE && pquien->o == TRUE ) //AL GRUPO
											//A LOS OTROS
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], S_IRGRP|S_IROTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], S_IWGRP|S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], S_IXGRP|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IWGRP|S_IXGRP|S_IWOTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], S_IRGRP|S_IWGRP|S_IXGRP|
						    S_IROTH|S_IWOTH|S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
	}					
	else if( paccion->menos == TRUE )						// SE REVOCA PERMISO
	{
		if( (pquien->u == FALSE && pquien->g == FALSE && pquien->o == FALSE) ||	//COMPORTAMIENTO chmod
		    (pquien->u == TRUE  && pquien->g == TRUE  && pquien->o == TRUE) )	// A TODOS
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], ~S_IRUSR|~S_IRGRP|~S_IROTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], ~S_IWUSR|~S_IWGRP|~S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], ~S_IXUSR|~S_IXGRP|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], ~S_IRUSR|~S_IRGRP|~S_IROTH|
						    ~S_IWUSR|~S_IWGRP|~S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRUSR|~S_IRGRP|~S_IROTH|
						    ~S_IXUSR|~S_IXGRP|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IWUSR|~S_IWGRP|~S_IWOTH|
						    ~S_IXUSR|~S_IXGRP|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRUSR|~S_IWUSR|~S_IXUSR|
						    ~S_IRGRP|~S_IWGRP|~S_IXGRP|
						    ~S_IROTH|~S_IWOTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == TRUE && pquien->g == FALSE && pquien->o == FALSE )	//AL USUARIO
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], ~S_IRUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], ~S_IWUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], ~S_IXUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], ~S_IRUSR|~S_IWUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRUSR|~S_IXUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IWUSR|~S_IXUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRUSR|~S_IWUSR|~S_IXUSR ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == FALSE && pquien->g == TRUE && pquien->o == FALSE ) //AL GRUPO
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], ~S_IRGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], ~S_IWGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], ~S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], ~S_IRGRP|~S_IWGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRGRP|~S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IWGRP|~S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRGRP|~S_IWGRP|~S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == FALSE && pquien->g == FALSE && pquien->o == TRUE ) //A LOS OTROS
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], ~S_IROTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], ~S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], ~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], ~S_IROTH|~S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IROTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IWOTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IROTH|~S_IWOTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == TRUE && pquien->g == TRUE && pquien->o == FALSE) // AL USUARIO
										       // AL GRUPO
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], ~S_IRUSR|~S_IRGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], ~S_IWUSR|~S_IWGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], ~S_IXUSR|~S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], ~S_IRUSR|~S_IRGRP|~S_IWUSR|~S_IWGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRUSR|~S_IRGRP|~S_IXUSR|~S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IWUSR|~S_IWGRP|~S_IXUSR|~S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRUSR|~S_IWUSR|~S_IXUSR|
						    ~S_IRGRP|~S_IWGRP|~S_IXGRP ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == TRUE && pquien->g == FALSE && pquien->o == TRUE ) //AL USUARIO
											//A LOS OTROS
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], ~S_IRUSR|~S_IROTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], ~S_IWUSR|~S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], ~S_IXUSR|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], ~S_IRUSR|~S_IWUSR|~S_IROTH|~S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRUSR|~S_IXUSR|~S_IROTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IWUSR|~S_IXUSR|~S_IWOTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRUSR|~S_IWUSR|~S_IXUSR|
						    ~S_IROTH|~S_IWOTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
		else if( pquien->u == FALSE && pquien->g == TRUE && pquien->o == TRUE ) //AL GRUPO
											//A LOS OTROS
		{
			if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == FALSE)
			{
				/* ERROR */
				message(stderr, EXIT_FAILURE);
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == FALSE)//DE LECTURA
			{
				if( chmod( argv[4], ~S_IRGRP|~S_IROTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == FALSE)//DE ESCRITURA
			{
				if( chmod( argv[4], ~S_IWGRP|~S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == FALSE && pmodo->x == TRUE)//DE EJECUCI�N
			{
				if( chmod( argv[4], ~S_IXGRP|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == FALSE) //DE LECTURA
			{								    //DE ESCRITURA
				
				if( chmod( argv[4], ~S_IRGRP|~S_IWGRP|~S_IROTH|~S_IWOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == FALSE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRGRP|~S_IXGRP|~S_IROTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == FALSE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE ESCRITURA
			{							  	     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IWGRP|~S_IXGRP|~S_IWOTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
			else if( pmodo->r == TRUE && pmodo->w == TRUE && pmodo->x == TRUE ) //DE LECTURA
			{							  	     //DE ESCRITURA
											     //DE EJECUCI�N
				
				if( chmod( argv[4], ~S_IRGRP|~S_IWGRP|~S_IXGRP|
						    ~S_IROTH|~S_IWOTH|~S_IXOTH ) == -1 )
				{
					message(stderr, EXIT_FAILURE);
				}
				else
				{
					fprintf(stdout,"\nPERMISOS APLICADOS EXITOSAMENTE!\n");
				}
			}
		}
	}
	else if( paccion->mas == FALSE && paccion->menos == FALSE )
	{
		/* ERROR */
		message(stderr, EXIT_FAILURE);
	}
}
		
			
/* FUNCI�N PRINCIPAL: main */

/*----------------------------------------------------------------------------
 * 	argv[0] <==> 	prog_name
 * 	
 * 	<quien>
 *	argv[1] <==|-->	u			"u" 
 * 		   |	| --> g 		"ug"
 * 		   |	|     | --> o		"ugo"
 * 		   |	|
 * 		   |	| --> o 		"uo"
 * 		   |	      | --> g			"uog"
 * 		   |	      
 * 		   |--> g 			"g"
 * 		   |	| --> u				"gu"
 * 		   |	|     | --> o			"guo"
 * 		   |	|
 * 		   |	| --> o			"go"			
 * 		   |	      | --> u			"gou"
 * 		   |	
 * 		   |--> o 			"o"
 * 		   |    | --> u 			"ou"
 * 		   |    |     | --> g			"oug"
 * 		   |    |
 * 		   |    | --> g				"og"
 * 		   |          | --> u			"ogu"
 * 		   |
 * 		   |--> a				"a"
 * 	
 * 	<+|->
 *	argv[2] <==| --> +
 *		   | --> -
 *	
 *	<modo>
 *	argv[3] <==| --> r			"r" 
 *		   |     | --> w 		"rw"
 *		   |     |     | --> x		"rwx"
 *		   |     |
 *		   |	 | --> x 		"rx"
 *		   |	       | --> w			"rxw"
 *		   |	       
 *		   |--> w 			"w"
 *		   |    | --> r 			"wr"
 *		   |    |     | --> x			"wrx"
 *		   |	|
 *		   |    | --> x			"wx"
 *		   |	      | --> r			"wxr"
 *		   |
 *		   |--> x			"x"
 *		   	| --> r				"xr"
 *		   	|     | --> w			"xrw" 
 *	 		|
 *	 		| --> w				"xw"
 *	 		      | --> r			"xwr"
 *	 		      
 *	argv[4] <==|--> path
 *-----------------------------------------------------------------------------*/
int main( int argc, char ** argv )
{
	prog_name = argv[0];
	
	if (argc < 5 || argc > 5)
	{
		message(stderr, EXIT_FAILURE);
	}
	
	pwho pquien = (pwho)(malloc( sizeof( struct who ) ));
	/*
	 * struct who quien;
	 * struct who * pquien = (struct who *) malloc( sizeof(quien) ) ; 
	 */
	pquien->u = FALSE;
	pquien->g = FALSE;
	pquien->o = FALSE;
	
	paction paccion = (paction)( malloc( sizeof( struct action ) ));
	paccion->mas = FALSE;
	paccion->menos = FALSE;
	
	pmode pmodo = (pmode)(malloc( sizeof( struct mode ) ));
	pmodo->r = FALSE;
	pmodo->w = FALSE;
	pmodo->x = FALSE;

	scan( argv, pquien, paccion, pmodo);

	choose( argv, pquien, paccion, pmodo);

	free(pmodo);
	free(paccion);
	free(pquien);
	
	return 0;
}
/* Fin del Archivo: my_chmod.c */
