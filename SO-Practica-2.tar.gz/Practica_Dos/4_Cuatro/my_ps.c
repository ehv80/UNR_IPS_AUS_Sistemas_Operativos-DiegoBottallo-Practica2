/* Archivo my_ps.c */
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

/* DEFINICIONES */
#define BUFSIZE 1024

/* VARIABLES GLOBALES */
DIR * pdir;
struct dirent * pdirent;
struct stat sstat;
char path[BUFSIZE];
char cmdlinepath[BUFSIZE];
int path_len, fd, leidos, cmdlinepath_len;
char buffer[BUFSIZE];

/* FUNCIONES */
void scan( char * path )
{
	path_len = strlen(path);	//ACTUALIZA TAMA�O DE path

	if( (pdir = opendir(path)) == 0)
	{
		perror("\nERROR: opendir\n");
		exit(1);
	}

	while( (pdirent = readdir( pdir )) != NULL )
	{
		path[path_len] = '\0';
		strcat(path, "/");
		strcat(path, pdirent->d_name);

		if( stat(path, &sstat) )
		{
			perror("\nERROR: stat\n");
			exit(2);
		}

		if( S_ISDIR(sstat.st_mode) )
		{
			printf("\nPID: %s\t", pdirent->d_name);
			//scan( path ); ???
			
			strcpy(cmdlinepath, path);
			cmdlinepath_len = strlen(cmdlinepath);
			cmdlinepath[cmdlinepath_len] = '\0';
			strcat(cmdlinepath, "/cmdline");
			if( (fd = open(cmdlinepath, O_RDONLY)) == -1)	//LO ABRE
			{
				perror("\nERROR: open\n");
				//exit(2);
			}
			while( (leidos = read(fd, buffer, sizeof(buffer))) > 0 ) //LO VA LEYENDO
			{
				printf("%s", buffer);				//LO VA IMPRIMIENDO
			}
			if( close(fd) == -1)	//LO CIERRA
			{
				perror("\nERROR: close\n");
				//exit(3);
			}
		}
	}

	if( closedir( pdir ) == -1 )
	{
		perror("\nERROR: closedir\n");
		exit(4);
	}
}


/* FUNCION PRINCIPAL MAIN */
int main()
{
	strcpy(path, "/proc"); //EL DIRECTORIO A EXAMINAR ES: /proc
	path_len = strlen(path);

	scan( path );

	return 0;
}	
/* Fin Archivo my_ps.c */
