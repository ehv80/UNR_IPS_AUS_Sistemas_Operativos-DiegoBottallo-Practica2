//Archivo: my_cat.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define SIZE 1024
#define TRUE 1
#define FALSE 0

int main( int argc , char * * argv )
{
	int fdLecturas[argc];
	/* Arreglo que contendr� los descriptores de 
	 * fichero que se abrir�n para lectura
	 */
	int fdEscritura; //decsriptor de archivo para escritura
	int i, leidos = -1, escritos = -1;
	int huboAperturaArchivoSalida = FALSE;
	char buffer[SIZE]; //buffer usado para lecturas y escrituras
	
	if( argc < 2 )
	{
		fprintf(stderr ,"\nUSO CORRECTO: %s <archivo1> <archivo2> ��� [-o <archivo_salida>]\n",
				argv[0] );
		exit(EXIT_FAILURE);
	}
	
	for( i=0 ; i<argc ; i++ ) // Inicializa el arreglo de descriptores
	{			  //de ficheros con "-1"
		fdLecturas[i] = -1;
	}
	
	for( i=1 ; i < argc ; i++ )
	{
		if( strcmp( argv[i] , "-o" ) == 0 )
		{	//en i-�simo argumento hay "-o"
			int j = i + 1;
			//en j-�simo argumento hay 
			//"nombre de archivo a abrir para escritura"
			if( (j < argc) && (argv[j] != NULL) )
			{
				if( (fdEscritura = open( argv[j], 
					O_WRONLY|O_CREAT|O_APPEND,
					0666 )) < 0 )
				{
					fprintf(stderr, "\nERROR AL ABRIR ARCHIVO PARA ESCRITURA!\n");
					exit(EXIT_FAILURE);
				}
				else
				{
					huboAperturaArchivoSalida = TRUE;
					i=j;
				}
			}
		}
		else
		{
			if( (fdLecturas[i] = open( argv[i] , O_RDONLY , 0666 )) < 0 )
			{
				fprintf(stderr, "\nERROR AL ABRIR ARCHIVO PARA LECTURA!\n");
				exit(EXIT_FAILURE);
			}
		}
	}
	//Hasta aqu� files descriptors abiertos, para leer, para escribir (si es necesario)

	if( huboAperturaArchivoSalida == TRUE )
	{
		for( i=1 ; i < argc ; i++ )
		{
			do{
				if( fdLecturas[i] != -1 )
				{
					if( (leidos = read( fdLecturas[i], buffer,
							sizeof(buffer) )) < 0 )
					{
						fprintf(stderr, "\nERROR AL LEER ARCHIVO!\n" );
						exit(EXIT_FAILURE);
					}
					else
					{
						if( (escritos = write(fdEscritura, buffer, leidos )) < 0)
						{
							fprintf(stderr, "\nERROR AL ESCRIBIR ARCHIVO!\n" );
							exit(EXIT_FAILURE);
						}
						else
						{
							fprintf(stdout, "\nESCRIBIENDO %d BYTES AL ARCHIVO!\n", escritos );
						}
					}
				}
			} while ( leidos > 0 );
		}
	}				
	else
	{
		for( i=1 ; i < argc ; i++ )
		{
			do{
				if( fdLecturas[i] != -1 )
				{
					if( (leidos = read( fdLecturas[i], buffer, sizeof(buffer) )) < 0 )
					{
						fprintf(stderr, "\nERROR AL LEER ARCHIVO!\n" );
						exit(EXIT_FAILURE);
					}
					else
					{
						if( (escritos = write( 1, buffer, leidos )) < 0 )
						{
							fprintf(stderr, "\nERROR AL ESCRIBIR ARCHIVO!\n" );
							exit(EXIT_FAILURE);
						}
					}
				}
			}while( leidos > 0 );
		}
	} 
	// Archivos se leen y escriben a otro archivo � a salida estandar
	
	//Falta cerrar los files descriptors
	
	for( i=0 ; i < argc ; i++ )
	{
		if( fdLecturas[i] != -1 )
		{
			if( close(fdLecturas[i]) < 0 )
			{
				fprintf( stderr , "\nERROR AL CERRAR ARCHIVO DE LECTURA!\n");
			}
		}
	}
	if( huboAperturaArchivoSalida == TRUE )
	{
		if( close(fdEscritura) < 0 )
		{
			fprintf( stderr , "\nERROR AL CERRAR ARCHIVO DE SALIDA!\n");
		}
	}
	return 0;
}
//Fin del archivo: my_cat.c
