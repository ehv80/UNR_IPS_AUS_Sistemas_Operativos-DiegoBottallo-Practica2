//Archivo forkprog2.c
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
	int i=0;
	int j;
	pid_t rf;

	rf = fork();
	switch(rf)
	{
		case -1:
			printf("No se ha podido crear el proceso hijo\n");
			break;
		case 0:
			//i=0;
			printf("Soy el hijo, mi PID es %d y mi variable i (inicialmente a %d) es par", getpid(), i);
			for(j=0; j < 5; j++)
			{
				i++;
				//i++;
				printf("\nSoy el proceso hijo, mi variable i es %d", i);
			}
			break;
		default:
			//i = 1;
			printf("Soy el padre, mi PID es %d y mi variable i (inicialmente a %d) es impar \n", getpid(), i );
			for(j=0; j < 5; j++)
			{
				i++;
				i++;
				printf("Soy el padre, mi variable i es %d \n", i);
			}
	}
	printf("\nFinal de ejecuci�n de %d \n", getpid() );
	exit(0);
}
//Fin Archivo forkprog2.c
