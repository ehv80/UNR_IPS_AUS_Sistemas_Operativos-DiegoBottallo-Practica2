//Archivo prog1.c
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char * argv[])
{
	int i;
	printf("Ejecutando el programa invocador (prog1).\n");
	printf("\tSus argumentos son: \n");
	for(i=0; i < argc; i++)
		printf("	argv[%d] : %s \n", i, argv[i]);
	sleep(10);
	strcpy(argv[0], "prog2");
	if( execv( "./prog2", argv) < 0)
	{
		printf("Error en la invocaci�n a prog2 \n");
		exit(1);
	}
	//c�digo inalcanzable, no se va a ejecutar
	printf("Saluda el proceso %s !\n", argv[0]);
	exit(0);
}
//Fin Archivo prog1.c
