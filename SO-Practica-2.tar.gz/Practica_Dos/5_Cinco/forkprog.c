// Archivo: forkprog.c
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int varfork=10,i=0;

int main()
{
	pid_t rf;

	rf = fork();
	switch(rf)
	{
		case -1:
			printf("No se ha podido crear el proceso hijo\n");
			break;
		case 0:
			sleep(5);
			printf("Soy el hijo, mi PID es %d y mi PPID es %d \n", getpid(), getppid() );
			for(i=0; i<10; i++)
				varfork++;
			sleep(20);
			printf("Proceso hijo varfork = %d \n", varfork);
			break;
		default:
			printf("Soy el padre, mi PID es %d y el PID de mi hijo es %d \n", getpid(), rf);
			for(i=0; i<10; i++)
				varfork += 10;
			sleep(30);
			printf("Proceso padre varfork = %d \n", varfork);
	}
	printf("Final de ejecuci�n de %d \n", getpid() );
	exit(0);
}
// Fin Archivo: forkprog.c
