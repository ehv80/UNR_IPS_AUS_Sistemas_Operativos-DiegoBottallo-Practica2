//Archivo: espe2.c
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main()
{
	pid_t rf;
	
	rf = fork();
	switch(rf)
	{
		case -1:
			printf("No he podido crear el proceso hijo\n");
			break;
		case 0:
			printf("Soy el hijo, mi PID es %d y mi PPID es %d\n", getpid(), getppid());
			sleep(10);
			break;
		default:
			//wait(0);
			//sleep(10);
			printf("Soy el padre, mi PID es %d y el PID de mi hijo es %d\n", getpid(), rf);
			//wait(0);
	}
	printf("Final de ejecuci�n de %d \n", getpid());
	exit(0);
}
//Fin Archivo: espe2.c
